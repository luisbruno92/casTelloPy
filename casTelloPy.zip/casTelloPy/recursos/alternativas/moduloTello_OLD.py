import tello as telloSource
import cv2
import pygame
import numpy as np
import time


# Frames per second of the pygame window display
FPS = 25


class Interfaz(object):
    print("CREANDO INTERFAZ")

    def __init__(self):

        self.dronControlado = False

        # Drone velocities between -100~100
        self.velocidad_adelante_atras = 0
        self.velocidad_izq_der = 0
        self.velocidad_abajo_arriba = 0
        self.velocidad_rotacion = 0
        self.speed = 10

        self.send_rc_control = False

        self.screen = False
        self.videoActivo = False

        self.controlesKeyDown = False

    def setearDronControlado(self, dron=False):
        if not dron:
            self.dronControlado = telloSource.dronControlado()
        else:
            self.dronControlado = dron

        if not self.dronControlado.connect():
            print("Tello not connected")
            return

        if not self.dronControlado.set_speed(self.speed):
            print("Not set speed to lowest possible")
            return

        # In case streaming is on. This happens when we quit this program without the escape key.
        if not self.dronControlado.streamoff():
            print("Could not stop video stream")
            return


    def setearVentanaPygame(self, ventana=False):
        if not ventana:
            print ("INICIANDO PYGAME")
          else:
            self.screen = ventana
        # create update timer
        pygame.time.set_timer(pygame.USEREVENT + 1, 50)

    def setearControlesKeyDown(self, funcion):
        self.controlesKeyDown = funcion

    def controlarKeyDown(self,that,teclaDown):
        if(self.controlesKeyDown):
            self.controlesKeyDown(self,teclaDown)

    def correr(self):
        print("CORRIENDO INTERFAZ")

        counter = 0
        should_stop = False
        while not should_stop:
            if self.screen:
                for event in pygame.event.get():
                    if event.type == pygame.USEREVENT + 1:
                        self.update()
                    elif event.type == pygame.QUIT:
                        should_stop = True
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            should_stop = True
                        else:
                            self.controlarKeyDown(self, event.key)
                    elif event.type == pygame.KEYUP:
                        self.keyup(event.key)

            if self.videoActivo:
                if self.frame_read.stopped:
                    self.frame_read.stop()
                    break
                if self.screen:
                    self.screen.fill([0, 0, 0])

                frame = cv2.cvtColor(self.frame_read.frame, cv2.COLOR_BGR2RGB)
                frame = np.rot90(frame)
                frame = np.flipud(frame)
                frame = pygame.surfarray.make_surface(frame)
                
                if self.screen:
                    self.screen.blit(frame, (0, 0))
                    pygame.display.update()

            time.sleep(1 / FPS)

        # Call it always before finishing. To deallocate resources.
        self.dronControlado.end()

    def activarVideo(self):
        if not self.dronControlado.streamon():
            print("Could not start video stream")
            return
        else:
            self.videoActivo = True
            self.frame_read = self.dronControlado.get_frame_read()

    def desactivarVideo(self):
        if not self.dronControlado.streamoff():
            print("Could not stop video stream")
            return
        else:
            self.videoActivo = False
            self.frame_read = False

    def update(self):
        """ Update routine. Send velocities to Tello."""
        if self.send_rc_control:
            self.dronControlado.send_rc_control(self.velocidad_izq_der, self.velocidad_adelante_atras, self.velocidad_abajo_arriba,
                                       self.velocidad_rotacion)


def main():

    velocidadMovimiento = 60

    miDron = telloSource.dronControlado()

    miInterfaz = Interfaz()
    miInterfaz.setearDronControlado(miDron)

    pygame.init()
    pygame.display.set_caption("Transmisión Video")
    miVentanaPygame = pygame.display.set_mode([960, 720])

    miInterfaz.setearVentanaPygame(miVentanaPygame)
    miInterfaz.activarVideo()
    
    def controlesKeyDown(dron, tecla):
        if tecla == pygame.K_UP:  # set forward velocity
            dron.velocidad_adelante_atras = velocidadMovimiento
        elif tecla == pygame.K_DOWN:  # set backward velocity
            dron.velocidad_adelante_atras = -velocidadMovimiento
        elif tecla == pygame.K_LEFT:  # set left velocity
            dron.velocidad_izq_der = -velocidadMovimiento
        elif tecla == pygame.K_RIGHT:  # set right velocity
            dron.velocidad_izq_der = velocidadMovimiento
        elif tecla == pygame.K_w:  # set up velocity
            dron.velocidad_abajo_arriba = velocidadMovimiento
        elif tecla == pygame.K_s:  # set down velocity
            dron.velocidad_abajo_arriba = -velocidadMovimiento
        elif tecla == pygame.K_a:  # set yaw counter clockwise velocity
            dron.velocidad_rotacion = -velocidadMovimiento
        elif tecla == pygame.K_d:  # set yaw clockwise velocity
            dron.velocidad_rotacion = velocidadMovimiento

        elif tecla == pygame.K_v:  # set yaw clockwise velocity
            if dron.videoActivo:
                dron.desactivarVideo()
            else:
                dron.activarVideo()

    def controlesKeyUp(dron, tecla):
        if tecla == pygame.K_UP or key == pygame.K_DOWN:  # set zero forward/backward velocity
            dron.velocidad_adelante_atras = 0
        elif tecla == pygame.K_LEFT or key == pygame.K_RIGHT:  # set zero left/right velocity
            dron.velocidad_izq_der = 0
        elif tecla == pygame.K_w or key == pygame.K_s:  # set zero up/down velocity
            dron.velocidad_abajo_arriba = 0
        elif tecla == pygame.K_a or key == pygame.K_d:  # set zero yaw velocity
            dron.velocidad_rotacion = 0
        elif tecla == pygame.K_t:  # takeoff
            dron.dronControlado.despegar()
            dron.send_rc_control = True
        elif tecla == pygame.K_l:  # land
            dron.dronControlado.aterrizar()
            dron.send_rc_control = False


    miInterfaz.setearControlesKeyDown(controlesKeyDown)


    miInterfaz.correr()

    


if __name__ == '__main__':
    main()
