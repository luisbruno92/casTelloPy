msj = ['mid', '-1', 'x', '0', 'y', '0', 'z', '0', 'mpry', '0,0,0', 'pitch', '0', 'roll', '2', 'yaw', '-106', 'vgx', '0', 'vgy', '0', 'vgz', '0', 'templ', '73', 'temph', '76', 'tof', '10', 'h', '0', 'bat', '66', 'baro', '-6.45', 'time', '34', 'agx', '-3.00', 'agy', '-33.00', 'agz', '-997.00']

for i in range(0, len(msj),2):
	print("POS " + str(i) + "--> " + msj[i] + ": " + msj[i+1])
