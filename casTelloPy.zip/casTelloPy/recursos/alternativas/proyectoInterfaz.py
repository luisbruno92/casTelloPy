# coding: utf8
import recursos.moduloTello as moduloTello
import recursos.moduloInterfaz as moduloInterfaz
import pygame
import tkinter
import threading
import datetime
import os
miRuta = os.path.dirname(os.path.abspath(__file__))

# --- SECCION INICIALIZACION ---

# INICIALIZAR DRON
miDron = moduloTello.Tello()
# miDron = moduloTello.TelloSinEstados() # Si existen problemas al decodificar según versión SDK

# CREAR INTERFAZ
miInterfaz = moduloInterfaz.Interfaz()

# SETEAR DRON CONTROLADO A LA INTERFAZ
miInterfaz.setear_dron_controlado(miDron)
 # miInterfaz.setear_logger_debug() # Para ver en tiempo real el envío de velocidades

# CONSULTAR POR CONSOLA NOMBRE OPERADOR FCC
nombreControlador = input("Ingrese su nombre: ")

#CREAR ARCHIVO DE REGISTRO
miArchivoRegistro = open(miRuta+"/registros/Mision de " + nombreControlador + ".txt", "a")
fyh= datetime.datetime.now()
miArchivoRegistro.write("Misión inicia fecha: " +str(fyh))

# ACTIVAR TRANSMISIÓN DE VIDEO
miInterfaz.activar_video()

# --- SECCION TKINTER ---

# CREAR TKINTER (TÍTULO, LABELS)
miVentana = tkinter.Tk()
miVentana.title("Interfaz de control FCC")
miLabel1 = tkinter.Label(miVentana, text = "Controlador: " + nombreControlador)
miLabel1.grid(column=1, row=1)

# FUNCIONES BOTONES TKINTER
def leerComandosArchivo():
	miInterfaz.setear_archivo(miRuta+"/misionVuelo.txt")
	miInterfaz.ejecutar_mision_archivo()

def controlAterrizaje():
	print("El usuario clickeó el botón Aterrizar")
	miDron.aterrizar()

def controlDespegue():
	fyh = datetime.datetime.now()
	miArchivoRegistro.write(nombreControlador + " despegó " + str(fyh))
	print("El usuario clickeó el botón Despegar")
	miDron.despegar()

def controlAdelante():
	print("El usuario clickeó el botón Adelante")
	distancia = 50
	miDron.mover_adelante(distancia)

def controlAdelante():
	print("El usuario clickeó el botón Adelante")
	distancia = 50
	miDron.mover_adelante(distancia)

def controlAtras():
	print("El usuario clickeó el botón Atrás")
	distancia = 50
	miDron.mover_atras(distancia)

def controlArriba():
	print("El usuario clickeó el botón Arriba")
	distancia = 50
	miDron.mover_arriba(distancia)

def controlAbajo():
	print("El usuario clickeó el botón Abajo")
	distancia = 50
	miDron.mover_abajo(distancia)

def controlDerecha():
	print("El usuario clickeó el botón Derecha")
	distancia = 50
	miDron.mover_derecha(distancia)

def controlIzquierda():
	print("El usuario clickeó el botón Derecha")
	distancia = 50
	miDron.mover_izquierda(distancia)

def controlTomarFoto():
	print("El usuario clickeó el botón Tomar Foto")
	fechaHoraActual = datetime.datetime.now()
	rutaImagenes = miRuta+"/imagenes/"
	miInterfaz.guardar_foto(rutaImagenes, fechaHoraActual)


# CREAR y AGREGAR BOTONES A VENTANA
botonMisionAutonoma = tkinter.Button(miVentana, text="Iniciar Misión Autónoma", command=leerComandosArchivo)
botonMisionAutonoma.grid(column=1, row=2)

botonAterrizaje = tkinter.Button(miVentana, text="Aterrizar", command=controlAterrizaje)
botonAterrizaje.grid(column=1, row=3)

botonDespegue = tkinter.Button(miVentana, text="Despegar", command=controlDespegue)
botonDespegue.grid(column=1, row=4)

botonAdelante = tkinter.Button(miVentana, text="Adelante", command=controlAdelante)
botonAdelante.grid(column=1, row=5)

botonAtras = tkinter.Button(miVentana, text="Atras", command=controlAtras)
botonAtras.grid(column=1, row=6)

botonArriba = tkinter.Button(miVentana, text="Arriba", command=controlArriba)
botonArriba.grid(column=1, row=7)

botonAbajo = tkinter.Button(miVentana, text="Abajo", command=controlAbajo)
botonAbajo.grid(column=1, row=8)

botonDerecha = tkinter.Button(miVentana, text="Derecha", command=controlDerecha)
botonDerecha.grid(column=1, row=9)

botonIzquierda = tkinter.Button(miVentana, text="Izquieda", command=controlIzquierda)
botonIzquierda.grid(column=1, row=10)

botonTomarFoto = tkinter.Button(miVentana, text="Tomar Foto", command=controlTomarFoto)
botonTomarFoto.grid(column=1, row=11)

# AGREGAR TKINTER A LA INTERFAZ
miInterfaz.setear_ventana_tkinter(miVentana)  

# ACTIVAR TKINTER
miVentana.mainloop()
# threadDobleVentana = threading.Thread(target=miVentana.mainloop(), args=()).start()

# --- SECCION PYGAME ---

# INICIALIZAR PYGAME
pygame.init()
pygame.display.set_caption("Transmisión de Video en Pygame")
miVentanaPygame = pygame.display.set_mode([960, 720])

# AGREGAR PYGAME A INTERFAZ
miInterfaz.setear_ventana_pygame(miVentanaPygame)

# --- SECCION CONTROLES REMOTOS ---

velocidadMovimiento = 60

# CONTROLES KEYDOWN TECLADO (OPCIONAL)
def controlesKeyDown(tecla):
	if tecla == pygame.K_w:
		miInterfaz.velocidad_abajo_arriba = velocidadMovimiento
	elif tecla == pygame.K_s:
		miInterfaz.velocidad_abajo_arriba = -velocidadMovimiento
	# AGREGÁ LOS CONTROLES QUE DESEES:
	elif tecla == pygame.K_UP:  # set forward velocity
		miInterfaz.velocidad_adelante_atras = velocidadMovimiento
	elif tecla == pygame.K_DOWN:  # set backward velocity
		miInterfaz.velocidad_adelante_atras = -velocidadMovimiento
	elif tecla == pygame.K_LEFT:  # set left velocity
		miInterfaz.velocidad_izq_der = -velocidadMovimiento
	elif tecla == pygame.K_RIGHT:  # set right velocity
		miInterfaz.velocidad_izq_der = velocidadMovimiento
	elif tecla == pygame.K_a:  # set yaw counter clockwise velocity
		miInterfaz.velocidad_rotacion = -velocidadMovimiento
	elif tecla == pygame.K_d:  # set yaw clockwise velocity
		miInterfaz.velocidad_rotacion = velocidadMovimiento

miInterfaz.setear_controles_key_down(controlesKeyDown)

# CONTROLES KEYUP TECLADO (OPCIONAL)
def controlesKeyUp(tecla):
	if tecla == pygame.K_w or tecla == pygame.K_s:
		miInterfaz.velocidad_abajo_arriba = 0
	elif tecla == pygame.K_t:
		miDron.despegar()
		miInterfaz.habilitar_controles_remotos()
	elif tecla == pygame.K_l:
		miDron.aterrizar()
		miInterfaz.deshabilitar_controles_remotos()
	# AGREGÁ LOS CONTROLES QUE DESEES:
	elif tecla == pygame.K_v:
		if miInterfaz.videoActivo:
			miInterfaz.desactivar_video()
		else:
			miInterfaz.activar_video()
	elif tecla == pygame.K_j:
		miInterfaz.setear_logger_debug()
	elif tecla == pygame.K_k:
		miInterfaz.setear_logger_info()
	elif tecla == pygame.K_UP or tecla == pygame.K_DOWN:
		miInterfaz.velocidad_adelante_atras = 0
	elif tecla == pygame.K_LEFT or tecla == pygame.K_RIGHT:
		miInterfaz.velocidad_izq_der = 0
	elif tecla == pygame.K_a or tecla == pygame.K_d:
		miInterfaz.velocidad_rotacion = 0
	elif tecla == pygame.K_b:
		print("LA BATERÍA ES: " + str(miDron.bat)) # Tiene que estar habilitada recepción estados
		# print("LA BATERÍA ES: " + str(miDron.obtener_bateria())) # Puede ejecutarse sin estar habilitada recepción de estados

miInterfaz.setear_controles_key_up(controlesKeyUp)

# CONTROLES GAMEPAD - INICIAR GAMEPAD
cantidadJoysticks = pygame.joystick.get_count()
# Importante, puede provocar errores si no se incluye condicional.
if cantidadJoysticks > 0:
	miGamepad = pygame.joystick.Joystick(0)
	miGamepad.init()

# CONTROLES GAMEPAD - BOTONES
def controlesBotonesGamepad(boton):
	if boton == 6:
		miDron.despegar()
		miInterfaz.habilitar_controles_remotos()
	elif boton == 7:
		miDron.aterrizar()
		miInterfaz.deshabilitar_controles_remotos()
	elif boton == 8:
		pass
		# tomar foto
	elif boton == 9:
		print("LA BATERÍA ES: " + str(miDron.bat))

miInterfaz.setear_controles_botones_gamepad(controlesBotonesGamepad)

# CONTROLES GAMEPAD - EJES

def controlesEjesGamepad():
	miInterfaz.velocidad_izq_der = int(velocidadMovimiento * miGamepad.get_axis(0))
	miInterfaz.velocidad_adelante_atras = int(-velocidadMovimiento*miGamepad.get_axis(1))
	miInterfaz.velocidad_abajo_arriba = int(-velocidadMovimiento*miGamepad.get_axis(2))
	miInterfaz.velocidad_rotacion  = int(velocidadMovimiento*miGamepad.get_axis(3))

miInterfaz.setear_controles_ejes_gamepad(controlesEjesGamepad)

# --- SECCION FINAL ---

# CORRER LA INTERFAZ
miInterfaz.correr()

# CERRAR ARCHIVO DE REGISTRO
miArchivoRegistro.close()
