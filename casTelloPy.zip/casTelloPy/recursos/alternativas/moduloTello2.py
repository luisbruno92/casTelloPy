import tello as telloSource
import cv2
import pygame
import numpy as np
import time
import os

miPath = os.path.dirname(os.path.abspath(__file__))


# Frames per second of the pygame window display
FPS = 25


class Interfaz(object):
    print("CREANDO INTERFAZ")

    def __init__(self):

        self.dronControlado = False

        # Drone velocities between -100~100
        self.velocidad_adelante_atras = 0
        self.velocidad_izq_der = 0
        self.velocidad_abajo_arriba = 0
        self.velocidad_rotacion = 0
        self.speed = 10

        self.send_rc_control = False

        self.screen = False
        self.videoActivo = False

        self.controlesKeyDown = False
        self.controlesKeyUp = False

    def setearDronControlado(self, dron=False):
        if not dron:
            self.dronControlado = telloSource.Tello()
        else:
            self.dronControlado = dron

        if not self.dronControlado.connect():
            print("Tello not connected")
            return

        if not self.dronControlado.set_sdk_data():
            print("SDK datos no recibidos")
            return

        if not self.dronControlado.set_speed(self.speed):
            print("Not set speed to lowest possible")
            return

        # dron.disable_mpads()

        # In case streaming is on. This happens when we quit this program without the escape key.
        if not self.dronControlado.streamoff():
            print("Could not stop video stream")
            return

    def setearVentanaPygame(self, ventana=False):
        if (not ventana):
            print ("INICIANDO PYGAME")
        else:
            self.screen = ventana

        pygame.time.set_timer(pygame.USEREVENT + 1, 50)

    def setearControlesKeyDown(self, funcion):
        self.controlesKeyDown = funcion

    def controlarKeyDown(self, teclaDown):
        if(self.controlesKeyDown):
            self.controlesKeyDown(teclaDown)

    def setearControlesKeyUp(self, funcion):
        self.controlesKeyUp = funcion

    def controlarKeyUp(self, teclaUp):
        if(self.controlesKeyUp):
            self.controlesKeyUp(teclaUp)

    def correr(self):
        print("CORRIENDO INTERFAZ")

        counter = 0
        should_stop = False
        while not should_stop:
            if self.screen:
                for event in pygame.event.get():
                    if event.type == pygame.USEREVENT + 1:
                        self.update()
                    elif event.type == pygame.QUIT:
                        should_stop = True
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            should_stop = True
                        else:
                            self.controlarKeyDown(event.key)
                    elif event.type == pygame.KEYUP:
                        self.controlarKeyUp(event.key)

            if self.videoActivo:
                if self.frame_read.stopped:
                    self.frame_read.stop()
                    break
                if self.screen:
                    self.screen.fill([0, 0, 0])

                frame = cv2.cvtColor(self.frame_read.frame, cv2.COLOR_BGR2RGB)
                frame = np.rot90(frame)
                frame = np.flipud(frame)
                frame = pygame.surfarray.make_surface(frame)
                
                if self.screen:
                    self.screen.blit(frame, (0, 0))
                    pygame.display.update()

            time.sleep(1 / FPS)

        # Call it always before finishing. To deallocate resources.
        self.dronControlado.end()

    def activarVideo(self):
        if not self.dronControlado.streamon():
            print("Could not start video stream")
            return
        else:
            self.videoActivo = True
            self.frame_read = self.dronControlado.get_frame_read()

    def desactivarVideo(self):
        if not self.dronControlado.streamoff():
            print("Could not stop video stream")
            return
        else:
            self.videoActivo = False
            self.frame_read = False

    def update(self):
        """ Update routine. Send velocities to Tello."""
        if self.send_rc_control:
            self.dronControlado.enviar_velocidades(self.velocidad_izq_der, self.velocidad_adelante_atras, self.velocidad_abajo_arriba,
                                       self.velocidad_rotacion)


def main():

    velocidadMovimiento = 60

    miDron = telloSource.Tello()

    miInterfaz = Interfaz()
    miInterfaz.setearDronControlado(miDron)

    pygame.init()
    pygame.display.set_caption("Transmisión Video")
    miVentanaPygame = pygame.display.set_mode([960, 720])

    miInterfaz.setearVentanaPygame(miVentanaPygame)
    miInterfaz.activarVideo()
    

    # OPCIONAL. Se les da el primer caso como ejemplo, completan el resto si lo desean.
    def controlesKeyDown(tecla):
        if tecla == pygame.K_UP:  # set forward velocity
            miInterfaz.velocidad_adelante_atras = velocidadMovimiento
        elif tecla == pygame.K_DOWN:  # set backward velocity
            miInterfaz.velocidad_adelante_atras = -velocidadMovimiento
        elif tecla == pygame.K_LEFT:  # set left velocity
            miInterfaz.velocidad_izq_der = -velocidadMovimiento
        elif tecla == pygame.K_RIGHT:  # set right velocity
            miInterfaz.velocidad_izq_der = velocidadMovimiento
        elif tecla == pygame.K_w:  # set up velocity
            miInterfaz.velocidad_abajo_arriba = velocidadMovimiento
        elif tecla == pygame.K_s:  # set down velocity
            miInterfaz.velocidad_abajo_arriba = -velocidadMovimiento
        elif tecla == pygame.K_a:  # set yaw counter clockwise velocity
            miInterfaz.velocidad_rotacion = -velocidadMovimiento
        elif tecla == pygame.K_d:  # set yaw clockwise velocity
            miInterfaz.velocidad_rotacion = velocidadMovimiento
        elif tecla == pygame.K_v:  # set yaw clockwise velocity
            if miInterfaz.videoActivo:
                miInterfaz.desactivarVideo()
            else:
                miInterfaz.activarVideo()

    miInterfaz.setearControlesKeyDown(controlesKeyDown)

    # OPCIONAL. Se les da despegar y aterrizar como ejemplo, completan el resto si lo desean.
    def controlesKeyUp(tecla):
        if tecla == pygame.K_t:  # takeoff
            miDron.despegar()
            miInterfaz.send_rc_control = True
        elif tecla == pygame.K_l:  # land
            miDron.aterrizar()
            miInterfaz.send_rc_control = False
        elif tecla == pygame.K_UP or tecla == pygame.K_DOWN:  # set zero forward/backward velocity
            miInterfaz.velocidad_adelante_atras = 0
        elif tecla == pygame.K_LEFT or tecla == pygame.K_RIGHT:  # set zero left/right velocity
            miInterfaz.velocidad_izq_der = 0
        elif tecla == pygame.K_w or tecla == pygame.K_s:  # set zero up/down velocity
            miInterfaz.velocidad_abajo_arriba = 0
        elif tecla == pygame.K_a or tecla == pygame.K_d:  # set zero yaw velocity
            miInterfaz.velocidad_rotacion = 0
        elif tecla == pygame.K_b:
            # print("LA BAT ES: " + str(miDron.get_battery()))
            f = open(miPath+"/textos/demofile3.txt", "a")
            f.write(miDron.response_state)


    miInterfaz.setearControlesKeyUp(controlesKeyUp)



    # AL FINAL DE TODO EL ARCHIVO - CORRER LA INTERFAZ
    miInterfaz.correr()

    
main()
